To install application
Ensure python version 3.12 has been installed
If python has not been installed download and run the .exe file from the Python Website:
https://www.python.org/downloads/

Once Python has been installed proceed to the github repository for the application and download the whole zip file. https://github.com/Donner-von-Swabia/SDEV-255-MineSweeper.git
After downloading the zip file, open the file and unzip the folder. Once the folder is unzipped you have installed the application.
To run the application, open the main.py file, if it does not open for the first time click on it again.
